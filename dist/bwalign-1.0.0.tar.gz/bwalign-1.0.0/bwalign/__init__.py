"""
bwalign.

A burrows-wheeler seed and extend aligner.
"""

__version__ = "1.0.0"
__authors__ = ['Adrian Layer, Nabil Khoury, Yasmin Jabir']