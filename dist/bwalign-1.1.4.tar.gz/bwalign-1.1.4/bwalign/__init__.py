"""
bwalign.

A burrows-wheeler seed and extend aligner.
"""

__version__ = "1.1.4"
__authors__ = ['Adrian Layer, Nabil Khoury, Yasmin Jabir']