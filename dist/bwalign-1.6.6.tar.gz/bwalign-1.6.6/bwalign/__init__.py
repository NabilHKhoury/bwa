"""
bwalign.

A burrows-wheeler seed and extend aligner.
"""

__version__ = "1.6.6"
__authors__ = ['Adrian Layer, Nabil Khoury, Yasmin Jabir']